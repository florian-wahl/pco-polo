<script src="../js/phaser/phaser.min.js"></script>
<script src="flappyBird.js"></script>