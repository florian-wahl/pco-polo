# Coil

Coil is an addictive HTML5 game where you have to defeat your enemies by enclosing them in your trail. Most of the game is drawn on 2d canvas but if WebGL support is detected additional effects are added.

Curious about how this looks in action? [Check out the live demo](http://hakim.se/experiments/html5/coil).

# License

MIT licensed

Copyright (C) 2011 Hakim El Hattab, http://hakim.se